﻿WPF Gradient Editor uses the ColorCanvas control from the Extended WPF Toolkit™ Community Edition.

http://wpftoolkit.codeplex.com/

The Xceed.Wpf.Toolkit.dll referenced by Gradient Editor resides in this folder and was built
from the source code provided by the Extended WPF Toolkit™ Community Edition project. 
Nothing was changed in their source code. 

If you prefer, download the source code (or the binaries) from the Extended WPF Toolkit™ Community Edition project
and use those.

